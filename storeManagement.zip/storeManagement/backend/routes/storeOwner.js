// const express = require('express');
// const router = express.Router();
// const db = require('../config/db'); // Your MySQL connection
// const { verifyToken } = require('../middleware/auth');


// // GET all ratings for stores owned by the logged-in store owner
// router.get('/', verifyToken, (req, res) => {
//   const ownerId = req.user.id; // `req.user` is populated by verifyToken middleware

//   const query = `
//     SELECT 
//       r.id,
//       s.name AS store_name,
//       r.id,
//       u.name AS user_name,
//       r.rating
//     FROM 
//       ratings r
//     JOIN store s ON r.id = s.id
//     JOIN registration u ON r.id = u.id
//     WHERE 
//       s.id = ?
//   `;

//   db.query(query, [ownerId], (err, results) => {
//     if (err) {
//       console.error("Database Error:", err);
//       return res.status(500).json({ message: 'Database error' });
//     }
//     res.json(results);
//   });
// });

// module.exports = router;


// routes/storeOwner.js

const express = require('express');
const router = express.Router();
const db = require('../config/db'); // your DB connection

// GET: List of users who rated a specific store
router.get('/store/rating', async (req, res) => {


  const query = `
    SELECT 
      r.name, 
      r.email, 
      rt.rating, 
   rt.store_id
    FROM ratings rt
    JOIN registration r ON rt.regi_id = r.id

  `;

  try {
    db.query(query, (err, results) => {
      if (err) {
        console.error('Database error:', err);
        return res.status(500).json({ message: 'Database error' });
      }

      return res.status(200).json(results);
    });
  } catch (error) {
    console.error('Server error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
