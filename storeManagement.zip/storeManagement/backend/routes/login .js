const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../config/db'); // Your MySQL DB connection
const router = express.Router();
const util = require('util');

// router.post('/login', async (req, res) => {
//   const { email, password } = req.body;

//   try {
//     const query = `
//       SELECT r.id as regi_id, r.password, rm.role_name AS role
//       FROM registration r
//       JOIN role_master rm ON r.role_id = rm.id
//       WHERE r.email = ?
//     `;
// // const query = 'SELECT * FROM registration WHERE email = ?'
//     db.query(query, [email], async (err, results) => {
//       if (err) {
//         console.error('DB error:', err);
//         return res.status(500).json({ message: 'Server error' });
//       }

//       if (results.length === 0) {
//         return res.status(401).json({ message: 'User not found' });
//       }

//       const user = results[0];

//       const isMatch = await bcrypt.compare(password, user.password);
//       if (!isMatch) {
//         return res.status(401).json({ message: 'Incorrect password' });
//       }

//       res.json({ regi_id: user.regi_id, role: user.role });
//     });
//   } catch (err) {
//     console.error('Login error:', err);
//     res.status(500).json({ message: 'Internal server error' });
//   }
// });

// router.post('/login', async (req, res) => {
//   const { email, password } = req.body;

//   // Fetch user by email
//   const query = `SELECT 
//   r.id AS regi_id,
//   r.name,
//   r.email,
//   r.password,
//   r.role_id,
//   rm.role_name 
// FROM 
//   registration r
// JOIN 
//   role_master rm ON r.role_id = rm.id
// WHERE 
//   r.email = ?
// `;
//   db.query(query, [email], async (err, results) => {
//     if (err) {
//       return res.status(500).json({ message: 'Server error' });
//     }

//     if (results.length === 0) {
//       return res.status(401).json({ message: 'Invalid credentials' });
//     }

//     const user = results[0];

//     // Compare password with bcrypt
//     const isMatch = await bcrypt.compare(password, user.password);
//     if (!isMatch) {
//       return res.status(401).json({ message: 'Incorrect password' });
//     }

//     // Password matched - login success
//     res.json({
//       message: 'Login successful',
//       user: {
//         regi_id: user.regi_id,
//         role_id: user.role_id,
//         name: user.name,
//         email: user.email,
//       }
//     });
//   });
// });


const query = util.promisify(db.query).bind(db);

// router.post('/login', async (req, res) => {
//   const { email, password } = req.body;

//   try {
//     const results = await query(`
//       SELECT r.id AS regi_id, r.password, r.role_id, rm.role_name
//       FROM registration r
//       JOIN role_master rm ON r.role_id = rm.id
//       WHERE r.email = ?
//     `, [email]);

//     if (results.length === 0) {
//       return res.status(401).json({ message: 'User not found' });
//     }

//     const user = results[0];
//     const isMatch = await bcrypt.compare(password, user.password);

//     if (!isMatch) {
//       return res.status(401).json({ message: 'Incorrect password' });
//     }

//     res.json({
//       message: 'Login successful',
//       user: {
//         regi_id: user.regi_id,
//         role_id: user.role_id,
//         role_name: user.role_name,
//         email: email,
//       }
//     });
//   } catch (error) {
//     console.error('Login error:', error);
//     res.status(500).json({ message: 'Server error' });
//   }
// });


// router.post('/login', async (req, res) => {
//   const { email, password } = req.body;

//   try {
//     if (!email || !password) {
//       return res.status(400).json({ message: 'Email and password are required' });
//     }

//     const query = `
//       SELECT r.id AS regi_id, r.password, r.role_id, r.name, r.email, rm.role_name
//       FROM registration r
//       JOIN role_master rm ON r.role_id = rm.id
//       WHERE r.email = ?
//     `;

//     db.query(query, [email], async (err, results) => {
//       if (err) {
//         console.error('Database error:', err);
//         return res.status(500).json({ message: 'Database error' });
//       }

//       if (results.length === 0) {
//         return res.status(401).json({ message: 'Invalid credentials' });
//       }

//       const user = results[0];

//       const isMatch = await bcrypt.compare(password, user.password);
//       if (!isMatch) {
//         return res.status(401).json({ message: 'Incorrect password' });
//       }

//       // Determine redirection path based on role_id
//       let redirectPath = '';
//       if (user.role_id === 1) redirectPath = '/admin-dashboard';
//       else if (user.role_id === 2) redirectPath = '/store-dashboard';
//       else if (user.role_id === 3) redirectPath = '/user-dashboard';
//       else return res.status(403).json({ message: 'Unknown role' });

//       return res.status(200).json({
//         message: 'Login successful',
//         regi_id: user.regi_id,
//         role: user.role_name,
//         redirect: redirectPath
//       });
//     });

//   } catch (err) {
//     console.error('Unexpected login error:', err);
//     return res.status(500).json({ message: 'Internal server error' });
//   }
// });

router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  const query = `
    SELECT r.id, r.password, r.role_id, r.name, r.email, rm.role_name
    FROM registration r
    JOIN role_master rm ON r.role_id = rm.id
    WHERE r.email = ?
  `;

  db.query(query, [email], async (err, results) => {
    if (err) {
      console.error('DB error:', err);
      return res.status(500).json({ message: 'Server error' });
    }

    if (results.length === 0) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    const user = results[0];

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ message: 'Incorrect password' });
    }

    let redirect = '';
    if (user.role_id === 1) redirect = '/adminDashboard';
    else if (user.role_id === 2) redirect = '/storeOwner';
    else if (user.role_id === 3) redirect = '/userDashboard';

    res.json({
      message: 'Login successful',
      regi_id: user.regi_id,
      role: user.role_name,
      redirect
    });
  });
});

module.exports = router;

