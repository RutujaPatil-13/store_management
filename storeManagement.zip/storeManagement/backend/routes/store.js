// const express = require('express');
// const { addRating, getStores } = require('../models/Store');
// const router = express.Router();
// const verifyToken = require('../middleware/auth');

// router.get('/', getStores);

// router.post('/:id/rate', verifyToken, (req, res) => {
//   const userId = req.user.id;
//   const storeId = req.params.id;
//   const { rating } = req.body;
//   if (rating < 1 || rating > 5) return res.status(400).send('Invalid rating');
//   addRating(storeId, userId, rating, (err) => {
//     if (err) return res.status(500).send('Failed to rate');
//     res.send('Rating submitted');
//   });
// });

// module.exports = router;

// const express = require('express');
// const router = express.Router();
// const db = require('../config/db'); 

// router.get('/', getStores);

// router.post('/:id/rate', verifyToken, (req, res) => {
//   const userId = req.user.id;
//   const storeId = req.params.id;
//   const { rating } = req.body;
//   if (rating < 1 || rating > 5) return res.status(400).send('Invalid rating');
//   addRating(storeId, userId, rating, (err) => {
//     if (err) return res.status(500).send('Failed to rate');
//     res.send('Rating submitted');
//   });
// });
// // GET all stores
// router.get('/', (req, res) => {
//   db.query('SELECT * FROM store', (err, results) => {
//     if (err) return res.status(500).json({ message: 'Database error' });
//     res.json(results);
//   });
// });

// module.exports = router;


const express = require('express');
const router = express.Router();
const db = require('../config/db'); // Your database connection

// GET all stores
router.get('/', (req, res) => {
  db.query('SELECT * FROM store', (err, results) => {
    if (err) return res.status(500).json({ message: 'Database error' });
    res.json(results);
  });
});

// POST rate a store
router.post('/:id/rate', (req, res) => {
  const storeId = req.params.id;
  const { userId, rating } = req.body;  // Make sure client sends userId and rating

  if (rating < 1 || rating > 5) return res.status(400).send('Invalid rating');

  const sql = `INSERT INTO ratings (store_id, user_id, rating) VALUES (?, ?, ?)`;
  db.query(sql, [storeId, userId, rating], (err, result) => {
    if (err) return res.status(500).send('Failed to rate');
    res.send('Rating submitted');
  });
});

module.exports = router;
