// const express = require('express');
// const bcrypt = require('bcrypt');
// const jwt = require('jsonwebtoken');
// const router = express.Router();
// const { createUser, findUser } = require('../models/User');
// const db = require('../config/db'); 


// const SECRET = 'your_jwt_secret';

// router.post('/register', async (req, res) => {
//   const { username, password, role } = req.body;
//   const hashed = await bcrypt.hash(password, 10);
//   createUser({ username, password: hashed, role }, (err) => {
//     if (err) return res.status(500).send('Error');
//     res.send('User Registered');
//   });
// });

// router.post('/login', (req, res) => {
//   const { username, password } = req.body;
//   findUser(username, async (err, results) => {
//     if (err || results.length === 0) return res.status(401).send('Invalid');
//     const match = await bcrypt.compare(password, results[0].password);
//     if (!match) return res.status(401).send('Wrong credentials');
//     const token = jwt.sign({ id: results[0].id, role: results[0].role }, SECRET);
//     res.json({ token });
//   });
// });

// app.get('/registration', (req, res) => {
//   res.json(users);
// });


// module.exports = router;


const express = require('express');
const router = express.Router();
const db = require('../config/db');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

// POST /api/login
router.post('/', (req, res) => {
  const { email, password } = req.body;

  db.query('SELECT * FROM registration WHERE email = ?', [email], async (err, results) => {
    if (err) return res.status(500).json({ message: 'Database error' });
    if (results.length === 0) return res.status(401).json({ message: 'Invalid email or password' });

    const user = results[0];

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(401).json({ message: 'Invalid email or password' });

    const token = jwt.sign({ id: user.id, role: user.role }, 'your_jwt_secret', { expiresIn: '1h' });

    res.json({ token, role: user.role });
  });
});

module.exports = router;
