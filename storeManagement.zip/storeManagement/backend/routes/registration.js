// const express = require('express');
// const router = express.Router();
// const db = require('../config/db');
// const bcrypt = require('bcryptjs');
// router.post('/', async (req, res) => {
//     const { name, email, password, address, role } = req.body;
//     if (role !== 'user') return res.status(400).json({ message: 'Only normal users can register' });
  
//     const hashedPassword = await bcrypt.hash(password, 10);
  
//     db.query(
//       'INSERT INTO registration (name, email, password, address, role) VALUES (?, ?, ?, ?, ?)',
//       [name, email, hashedPassword, address, role],
//       (err, result) => {
//         if (err) return res.status(500).json({ message: 'Database error' });
//         res.status(201).json({ message: 'User registered successfully' });
//       }
//     );
  

//   // Map role to role_id
//   let role_id;
//   if (role === 'admin') role_id = 1;
//   else if (role === 'store_owner') role_id = 2;
//   else if (role === 'user') role_id = 3;
//   else return res.status(400).json({ message: 'Invalid role' });

//   const query = 'INSERT INTO registration (role_id, name, email, password, address) VALUES (?, ?, ?, ?, ?)';
//   db.query(query, [role_id, name, email, password, address], (err, result) => {
//     if (err) {
//       console.error('DB Error:', err);
//       return res.status(500).json({ message: 'Database error' });
//     }
//     res.status(201).json({ message: 'User registered successfully', userId: result.insertId });
//   });
// });

// module.exports = router;

// const express = require('express');

// const db = require('../config/db');
// const bcrypt = require('bcryptjs');

// router.post('/', async (req, res) => {
//   const { name, email, password, address ,role_id} = req.body;

//   // Optional: validate required fields
//   if (!name || !email || !password || !address || !role_id ) {
//     return res.status(400).json({ message: 'All fields are required' });
//   }

//   try {
//     const hashedPassword = await bcrypt.hash(password, 10);

//     // Insert user into the registration table
//     const query = 'INSERT INTO registration (name, email, password, address,role_id) VALUES ( ?, ?, ?, ,?,?)';
//     db.query(query, [name, email, hashedPassword, address,role_id], (err, result) => {
//       if (err) {
//         console.error('DB Error:', err);
//         return res.status(500).json({ message: 'Database error' });
//       }

//       return res.status(201).json({ message: 'User registered successfully', userId: result.insertId });
//     });

//   } catch (err) {
//     console.error('Hashing Error:', err);
//     return res.status(500).json({ message: 'Server error' });
//   }
// });

// const express = require('express');
// const router = express.Router();
// const db = require('../config/db');
// const bcrypt = require('bcryptjs');

// router.post('/', async (req, res) => {
//   const { name, email, password, address } = req.body;

//   // Optional: validate required fields
//   if (!name || !email || !password || !address  ) {
//     return res.status(400).json({ message: 'All fields are required' });
//   }

//   try {
//     const hashedPassword = await bcrypt.hash(password, 10);

//     // Insert user into the registration table
//     const query = 'INSERT INTO registration (name, email, password, address) VALUES ( ?, ?, ?, ?)';
//     db.query(query, [name, email, hashedPassword, address], (err, result) => {
//       if (err) {
//         console.error('DB Error:', err);
//         return res.status(500).json({ message: 'Database error' });
//       }

//       return res.status(201).json({ message: 'User registered successfully', userId: result.insertId });
//     });

//   } catch (err) {
//     console.error('Hashing Error:', err);
//     return res.status(500).json({ message: 'Server error' });
//   }
// });

// module.exports = router;



const express = require('express');
const router = express.Router();
const db = require('../config/db');
const bcrypt = require('bcryptjs');

router.post('/', async (req, res) => {
  const { name, email, password, address } = req.body;

  if (!name || !email || !password || !address) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  try {
    const hashedPassword = await bcrypt.hash(password, 10);

    const query = `
      INSERT INTO registration (name, email, password, address, role_id)
      VALUES (?, ?, ?, ?, ?)
    `;
    const roleId = 3; // Default role_id for user

    db.query(query, [name, email, hashedPassword, address, roleId], (err, result) => {
      if (err) {
        console.error('DB Error:', err);
        return res.status(500).json({ message: 'Database error' });
      }

      return res.status(201).json({
        message: 'User registered successfully',
        userId: result.insertId
      });
    });

  } catch (err) {
    console.error('Hashing Error:', err);
    return res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
