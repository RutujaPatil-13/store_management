const express = require('express');
const router = express.Router();
const db = require('../config/db'); // Adjust path to your DB config

// POST /api/stores - Add a new store
router.post('/', (req, res) => {
  const { name, store_address } = req.body;

  if (!name || !store_address) {
    return res.status(400).json({ message: 'Name and address are required' });
  }

  const query = 'INSERT INTO store (name,store_address,email) VALUES (?, ?,?)';
  db.query(query, [name, store_address], (err, result) => {
    if (err) {
      console.error('Error inserting store:', err);
      return res.status(500).json({ message: 'Database error' });
    }

    return res.status(201).json({
      message: 'Store added successfully',
      storeId: result.insertId,
    });
  });
});

module.exports = router;
