const express = require('express');
const router = express.Router();
// const db = require('../config/db');
// const bcrypt = require('bcryptjs');

// router.post('/', async (req, res) => {
//   const { email, password } = req.body;

//   try {
//     const [rows] = await db.promise().query('SELECT * FROM registration WHERE email = ?', [email]);

//     if (rows.length === 0) {
//       return res.status(401).json({ message: 'Email not found' });
//     }

//     const user = rows[0];

//     const isMatch = await bcrypt.compare(password, user.password);
//     if (!isMatch) {
//       return res.status(401).json({ message: 'Incorrect password' });
//     }

//     res.status(200).json({
//       message: 'Login successful',
//       role: user.role,
//       email: user.email,
//       userId: user.id
//     });
//   } catch (error) {
//     console.error('Login error:', error);
//     res.status(500).json({ message: 'Internal server error' });
//   }
// });

// module.exports = router;

router.post('/', (req, res) => {
    const { email, password } = req.body;
  
    db.query('SELECT * FROM registration WHERE email = ?', [email], async (err, results) => {
      if (err) return res.status(500).json({ message: 'Server error' });
  
      if (results.length === 0) return res.status(401).json({ message: 'Invalid email or password' });
  
      const user = results[0];
  
      // If you use bcrypt
      const match = await bcrypt.compare(password, user.password);
      if (!match) return res.status(401).json({ message: 'Invalid email or password' });
  
   
      return res.status(200).json({ 
        role: user.role, 
        email: user.email, 
        userId: user.id 
      });
    });
  });
  
