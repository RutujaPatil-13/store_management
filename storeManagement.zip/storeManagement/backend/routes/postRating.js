const express = require('express');
const router = express.Router();
const db = require('../config/db');

// router.post('/:storeId/rating', (req, res) => {
//   const storeId = req.params.storeId;
//   const { userId, rating } = req.body;

//   if (!userId || !rating || rating < 1 || rating > 5) {
//     return res.status(400).json({ error: 'Invalid userId or rating (1-5)' });
//   }

//   // Step 1: Insert or update the user rating in the rating table
//   const insertRatingQuery = `
//     INSERT INTO rating (store_id, user_id, rating)
//     VALUES (?, ?, ?)
//     ON DUPLICATE KEY UPDATE rating = ?
//   `;

//   db.query(insertRatingQuery, [storeId, userId, rating, rating], (err) => {
//     if (err) {
//       console.error('Error inserting/updating rating:', err);
//       return res.status(500).json({ error: 'Failed to submit rating' });
//     }

//     // Step 2: Calculate new average rating
//     const avgRatingQuery = `
//       SELECT AVG(rating) AS averageRating FROM rating WHERE store_id = ?
//     `;

//     db.query(avgRatingQuery, [storeId], (err, results) => {
//       if (err) {
//         console.error('Error calculating average rating:', err);
//         return res.status(500).json({ error: 'Failed to calculate average rating' });
//       }

//       const averageRating = results[0].averageRating || 0;

//       // Step 3: Update the store table with new average rating
//       const updateStoreQuery = `
//         UPDATE store SET rating = ? WHERE id = ?
//       `;

//       db.query(updateStoreQuery, [averageRating, storeId], (err) => {
//         if (err) {
//           console.error('Error updating store rating:', err);
//           return res.status(500).json({ error: 'Failed to update store rating' });
//         }

//         res.json({ message: 'Rating submitted and store rating updated', averageRating });
//       });
//     });
//   });
// });



// POST API for rating a store
router.post('/api/postrating/:storeId/rating', (req, res) => {
  const { storeId } = req.params;
  const { rating } = req.body;

  if (!rating ) {
    return res.status(400).json({ message: 'Missing rating or regi_id' });
  }

  const query = 'INSERT INTO ratings (store_id, rating) VALUES (?, ?)';
  db.query(query, [storeId, rating], (err, result) => {
    if (err) {
      console.error('Error posting rating:', err);
      return res.status(500).json({ message: 'Server error' });
    }
    res.status(201).json({ message: 'Rating submitted successfully' });
  });
});


module.exports = router;


