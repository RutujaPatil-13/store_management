import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import '../css/addStore.css'

function AddStore() {
  const [store, setStore] = useState({ name: '', store_address: '' });
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/stores', store);
      alert('Store added successfully!');
      navigate('/adminDashboard'); // Redirect to Admin Dashboard after adding
    } catch (error) {
      alert('Failed to add store');
      console.error(error);
    }
  };

  return (
    <div className="add-store-container">
    <h2>Add New Store</h2>
    <form className="add-store-form" onSubmit={handleSubmit}>
      <input
        placeholder="Store Name"
        value={store.name}
        onChange={(e) => setStore({ ...store, name: e.target.value })}
      />
      <textarea
        placeholder="Store Address"
        value={store.store_address}
        onChange={(e) => setStore({ ...store, store_address: e.target.value })}
        rows={4}
      />
        <input
        placeholder="Store Email"
        value={store.email}
        onChange={(e) => setStore({ ...store, email: e.target.value })}
      />
      <button type="submit">Add Store</button>
    </form>
  </div>
  );
}

export default AddStore;
