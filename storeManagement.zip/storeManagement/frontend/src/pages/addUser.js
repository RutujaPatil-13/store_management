// import React, { useState } from 'react';
// import axios from 'axios';
// import '../css/addUser.css'; // Import the CSS

// function AddUserForm() {
//   const [formData, setFormData] = useState({
//     name: '',
//     address: '',
//     email: '',
//     password: ''
//   });

//   const handleChange = (e) => {
//     setFormData({...formData, [e.target.name]: e.target.value});
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     try {
//     //   await axios.post('http://localhost:5000/api/user', formData);

//     await axios.post('http://localhost:5000/api/user', {
          
//         role: 'user'
//          ,...formData
//       });
//       alert('User registered successfully!');
//       setFormData({ name: '', address: '', email: '', password: '' });
//     } catch (error) {
//       console.error('Error registering user:', error);
//       alert('Failed to register user.');
//     }
//   };

//   return (
//     <div className="add-user-container">
//       <h2>Register New User</h2>
//       <form onSubmit={handleSubmit} className="add-user-form">
//         <label>Name</label>
//         <input type="text" name="name" value={formData.name} onChange={handleChange} required />

//         <label>Address</label>
//         <input type="text" name="address" value={formData.address} onChange={handleChange} required />

//         <label>Email</label>
//         <input type="email" name="email" value={formData.email} onChange={handleChange} required />

//         <label>Password</label>
//         <input type="password" name="password" value={formData.password} onChange={handleChange} required />

//         <button type="submit">Register</button>
//       </form>
//     </div>
//   );
// }

// export default AddUserForm;


import React, { useState } from 'react';
import axios from 'axios';
import '../css/register.css';
import { useNavigate } from 'react-router-dom';

function AddUserForm() {
  const [data, setData] = useState({
    name: "",
    address: "",
    password: "",
    email: "",
  });

  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const validate = () => {
    const errs = {};

    if (!data.name.trim()) {
      errs.name = "Name is required";
    } else if (data.name.length < 20 || data.name.length > 60) {
      errs.name = "Name must be between 20 and 60 characters";
    }

    if (!data.address) {
      errs.address = "Address is required";
    } else if (data.address.length > 400) {
      errs.address = "Address cannot exceed 400 characters";
    }

    if (!data.password) {
      errs.password = "Password is required";
    } else if (
      data.password.length < 8 ||
      data.password.length > 16 ||
      !/[A-Z]/.test(data.password) ||
      !/[!@#$%^&*(),.?":{}|<>]/.test(data.password)
    ) {
      errs.password =
        "Password must be 8-16 characters and include at least one uppercase letter and one special character";
    }

    if (!data.email) {
      errs.email = "Email is required";
    } else {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
      if (!emailRegex.test(data.email)) {
        errs.email = "Invalid email address";
      }
    }

    return errs;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length === 0) {
      try {
        await axios.post('http://localhost:5000/api/register', {
          
          role: 'user'
           ,...data
        });
        alert('Registered!');
        navigate('/adminDashboard');
      } catch (error) {
        alert('Registration failed.');
        console.error(error);
      }
    }
  };


  return (
    <form className="register-form" onSubmit={handleSubmit} noValidate>
      <input
        className="input"
        type="text"
        placeholder="Name"
        value={data.name}
        onChange={(e) => setData({ ...data, name: e.target.value })}
      />
      {errors.name && <p className="error-text">{errors.name}</p>}

      <textarea
        className="input"
        placeholder="Address"
        value={data.address}
        onChange={(e) => setData({ ...data, address: e.target.value })}
        rows={4}
      />
      {errors.address && <p className="error-text">{errors.address}</p>}

      <input
        className="input"
        type="password"
        placeholder="Password"
        value={data.password}
        onChange={(e) => setData({ ...data, password: e.target.value })}
      />
      {errors.password && <p className="error-text">{errors.password}</p>}

      <input
        className="input"
        type="email"
        placeholder="Email"
        value={data.email}
        onChange={(e) => setData({ ...data, email: e.target.value })}
      />
      {errors.email && <p className="error-text">{errors.email}</p>}

      <button className="submit-btn" type="submit">
        Submit
      </button>
    </form>
  );
}

export default AddUserForm;
