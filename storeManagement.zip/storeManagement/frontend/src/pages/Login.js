// // import React, { useState } from 'react';
// // import axios from 'axios';
// // import { useNavigate } from 'react-router-dom';
// // import '../css/login.css'

// // function Login() {
// //   const [email, setEmail] = useState('');
// //   const [password, setPassword] = useState('');
// //   const navigate = useNavigate();

// //   const handleLogin = async (e) => {
// //     e.preventDefault();
// //     try {
// //       const [rows] = await db.query("SELECT * FROM registration WHERE email = ? AND password = ?");
    
// //       const { token, role } = res.data;
// //       localStorage.setItem('token', token);

// //       // Redirect based on role
// //       if (role === 'admin') navigate('/admin/dashboard');
// //       else if (role === 'store_owner') navigate('/store/dashboard');
// //       else navigate('/user/home');
// //     } catch (error) {
// //       alert('Invalid credentials');
// //       console.error(error);
// //     }
// //   };

// //   return (
// //     <form onSubmit={handleLogin}>
// //       <input
// //         type="email"
// //         placeholder="Email"
// //         value={email}
// //         onChange={(e) => setEmail(e.target.value)}
// //         required
// //       />
// //       <input
// //         type="password"
// //         placeholder="Password"
// //         value={password}
// //         onChange={(e) => setPassword(e.target.value)}
// //         required
// //       />
// //       <button type="submit">Login</button>
// //     </form>
// //   );
// // }

// // export default Login;


// import React, { useState } from 'react';
// import axios from 'axios';
// import { useNavigate } from 'react-router-dom';
// import '../css/login.css';

// function Login() {
//   const [email, setEmail] = useState('');
//   const [password, setPassword] = useState('');
//   const navigate = useNavigate();

//   const handleLogin = async (e) => {
//     e.preventDefault();
//     try {
//       const res = await axios.post('http://localhost:5000/login', {
//         email,
//         password
//       });

//       const { token, role } = res.data;
//       localStorage.setItem('token', token);

//       // Redirect based on role
//       if (role === 'admin') navigate('/admin/dashboard');
//       else if (role === 'store_owner') navigate('/store/dashboard');
//       else navigate('/user/home');
//     } catch (error) {
//       alert('Invalid credentials');
//       console.error(error);
//     }
//   };

//   return (
//     <form onSubmit={handleLogin}>
//       <input
//         type="email"
//         placeholder="Email"
//         value={email}
//         onChange={(e) => setEmail(e.target.value)}
//         required
//       />
//       <input
//         type="password"
//         placeholder="Password"
//         value={password}
//         onChange={(e) => setPassword(e.target.value)}
//         required
//       />
//       <button type="submit">Login</button>
//     </form>
//   );
// }

// export default Login;


// import React, { useState } from 'react';
// import axios from 'axios';
// import { useNavigate } from 'react-router-dom';
//  import '../css/login.css'

// function Login() {
//   const [email, setEmail] = useState('');
//   const [password, setPassword] = useState('');
//   const navigate = useNavigate();

//   const handleLogin = async (e) => {
//     e.preventDefault();

//     try {
//       const res = await axios.post('http://localhost:5000/login', { email, password });
//       const { role } = res.data;

//       // Redirect based on role
//       if (role === 'admin') navigate('/admin/dashboard');
//       else if (role === 'store_owner') navigate('/store/dashboard');
//       else navigate('/user/home');
//     } catch (error) {
//       alert('Login failed. Check credentials.');
//       console.error('Login error:', error);
//     }
//   };

//   return (
//     <form onSubmit={handleLogin}>
//       <input
//         type="email"
//         placeholder="Email"
//         value={email}
//         onChange={(e) => setEmail(e.target.value)}
//         required
//       />
//       <input
//         type="password"
//         placeholder="Password"
//         value={password}
//         onChange={(e) => setPassword(e.target.value)}
//         required
//       />
//       <button type="submit">Login</button>
//     </form>
//   );
// }

// export default Login;


// import React, { useState } from 'react';
// import axios from 'axios';
// import { useNavigate } from 'react-router-dom';
// import '../css/login.css';

// function Login() {
//   const [email, setEmail] = useState('');
//   const [password, setPassword] = useState('');
//   const [errors, setErrors] = useState({});
//   const navigate = useNavigate();
//   const [error, setError] = useState('');

//   // Basic email and password validation
//   const validate = () => {
//     const errors = {};
//     if (!email) {
//       errors.email = 'Email is required';
//     } else if (!/\S+@\S+\.\S+/.test(email)) {
//       errors.email = 'Email is invalid';
//     }

//     if (!password) {
//       errors.password = 'Password is required';
//     } else if (password.length < 6) {
//       errors.password = 'Password must be at least 6 characters';
//     }

//     setErrors(errors);
//     return Object.keys(errors).length === 0;
//   };

//   const handleLogin = async (e) => {
//     e.preventDefault();
//     setError('');
//     if (!validate()) return;

//     try {
//       const response = await axios.post('http://localhost:5000/api/login', {
//         email,
//         password: password.toString(),

//       });
//       console.log({ email, password });
//       const user = response.data;
//       if (role_id === 1) {
//         navigate('/admin-dashboard');
//       } else if (role_id === 2) {
//         navigate('/store-owner-dashboard');
//       } else if (role_id === 3) {
//         navigate('/userDashboard');
//       } else {
//         setError('Unknown role. Cannot redirect.');
//       }
//     } catch (error) {
//       alert('Login failed. Please check your credentials.');
//     }
//   };

//   return (
//     <div className="login-container">
//       <form onSubmit={handleLogin}>
//         <h2>Login</h2>
//         <input
//           type="email"
//           placeholder="Email"
//           value={email}
//           onChange={(e) => setEmail(e.target.value)}
//         />
//         {errors.email && <p className="error">{errors.email}</p>}

//         <input
//           type="password"
//           placeholder="Password"
//           value={password}
//           onChange={(e) => setPassword(e.target.value)}
//         />
//         {errors.password && <p className="error">{errors.password}</p>}

//         <button type="submit">Login</button>
//       </form>
//     </div>
//   );
// }

// export default Login;


import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import '../css/login.css';

function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({});
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const validate = () => {
    const errors = {};
    if (!email) {
      errors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      errors.email = 'Invalid email format';
    }

    if (!password) {
      errors.password = 'Password is required';
    } else if (password.length < 6) {
      errors.password = 'Password must be at least 6 characters';
    }

    setErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setError('');

    if (!validate()) return;

    try {
      const response = await axios.post('http://localhost:5000/api/login', {
        email,
        password
      });

      console.log('Login Response:', response.data);

      // Handle the role-based redirect
      const { regi_id, role, redirect } = response.data;

      if (redirect) {
        // optionally save regi_id in state/context if needed
        navigate(redirect);
      } else {
        setError('Unknown role or missing redirect path.');
      }
    } catch (error) {
      console.error('Login error:', error.response?.data || error.message);
      setError('Login failed. Please check your credentials.');
    }
  };

  return (
    <div className="login-container">
      <form onSubmit={handleLogin}>
        <h2>Login</h2>

        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        {errors.email && <p className="error">{errors.email}</p>}

        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        {errors.password && <p className="error">{errors.password}</p>}

        {error && <p className="error">{error}</p>}

        <button type="submit">Login</button>
      </form>
    </div>
  );
}

export default Login;
