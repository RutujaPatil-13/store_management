// import React from 'react';
// import { useNavigate } from 'react-router-dom';
// import '../css/home1.css'; // Create styling in this CSS file

// const Home1 = () => {
//   const navigate = useNavigate();

//   return (
//     <div className="home-container">
//       <header className="home-header">
//         <h1></h1>
//         <nav className="home-nav">
//           <button onClick={() => navigate('/store')}>Store Owner</button>
//           <button onClick={() => navigate('/adminDashboard')}>Admin</button>
//           <button onClick={() => navigate('/user')}>User</button>
//         </nav>
//       </header>
//       <main className="home-main">
//         <h2>Welcome to the Platform</h2>
//         <p>Register or log in to start exploring stores and rating them!</p>
//       </main>
//     </div>
//   );
// };

// export default Home1;


// Home.js
import React from 'react';
import { useNavigate } from 'react-router-dom';
import '../css/home1.css';

const Home1 = () => {
  const navigate = useNavigate();

  const handleRoleClick = (role) => {
    localStorage.setItem('selectedRole', role);  // Store role in localStorage
    navigate('/login');                          // Redirect to login
  };

  return (
    <div className="home-wrapper">
      <div className="overlay">
        <header className="home-header">
          <h1>Welocme to Webiste</h1>
          <p>Discover. Rate. Connect.</p>
        </header>
        <div className="role-buttons">
          <button onClick={() => handleRoleClick('store-owner')}>Store Owner</button>
          <button onClick={() => handleRoleClick('admin')}>Admin</button>
          <button onClick={() => handleRoleClick('user')}>User</button>
        </div>
      </div>
    </div>
  );
};

export default Home1;
