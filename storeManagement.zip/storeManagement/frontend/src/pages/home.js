import React from 'react';
import { Link } from 'react-router-dom';
import '../css/home.css';

function Home() {
  return (
    <div className="home-container">
      <div className="home-hero">
        <h1>Welcome to the Store Management System</h1>
        <p>Discover, rate, and manage stores effortlessly.</p>
        <div className="home-buttons">
          <Link to="/login" className="home-btn">Login</Link>
          <Link to="/register" className="home-btn">Sign Up</Link>
        </div>
      </div>

      <div className="home-features">
        <h2>Features</h2>
        <div className="feature-grid">
          <div className="feature-card">
            <h3>Search Stores</h3>
            <p>Quickly search by name or address to find the best stores.</p>
          </div>
          <div className="feature-card">
            <h3>Rate Stores</h3>
            <p>Submit your ratings from 1 to 5 and share your experience.</p>
          </div>
          <div className="feature-card">
            <h3>Admin Control</h3>
            <p>Admins can manage users and monitor store activity.</p>
          </div>
          <div className="feature-card">
            <h3>Secure Access</h3>
            <p>Sign up and login securely to manage your store preferences.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Home;
