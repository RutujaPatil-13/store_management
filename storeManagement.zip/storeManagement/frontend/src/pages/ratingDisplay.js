// src/components/StarRating.js
import React from 'react';
import { FaStar } from 'react-icons/fa';

const StarRating = ({ rating = 0, onRatingChange }) => {
  return (
    <div>
      {[...Array(5)].map((_, i) => {
        const starValue = i + 1;
        return (
          <FaStar
            key={i}
            size={24}
            style={{ cursor: 'pointer', marginRight: 5 }}
            color={starValue <= rating ? '#ffc107' : '#e4e5e9'}
            onClick={() => onRatingChange(starValue)}
          />
        );
      })}
    </div>
  );
};

export default StarRating;
