// import React, { useState } from 'react';
// import axios from 'axios';

// function ChangePassword({ regi_id }) {
//   const [currentPassword, setCurrentPassword] = useState('');
//   const [newPassword, setNewPassword] = useState('');
//   const [confirmPassword, setConfirmPassword] = useState('');
//   const [message, setMessage] = useState('');

//   const handleUpdate = async (e) => {
//     e.preventDefault();

//     if (newPassword !== confirmPassword) {
//       setMessage('New passwords do not match.');
//       return;
//     }

//     try {
//       const res = await axios.put('http://localhost:5000/api/update-password', {
//         regi_id,
//         currentPassword,
//         newPassword,
//       });

//       setMessage(res.data.message);
//       setCurrentPassword('');
//       setNewPassword('');
//       setConfirmPassword('');
//     } catch (err) {
//       setMessage(err.response?.data?.message || 'Error updating password');
//     }
//   };

//   return (
//     <div>
//       <h2>Change Password</h2>
//       <form onSubmit={handleUpdate}>
//         <input
//           type="password"
//           placeholder="Current Password"
//           value={currentPassword}
//           onChange={(e) => setCurrentPassword(e.target.value)}
//           required
//         />
//         <input
//           type="password"
//           placeholder="New Password"
//           value={newPassword}
//           onChange={(e) => setNewPassword(e.target.value)}
//           required
//         />
//         <input
//           type="password"
//           placeholder="Confirm New Password"
//           value={confirmPassword}
//           onChange={(e) => setConfirmPassword(e.target.value)}
//           required
//         />
//         <button type="submit">Update Password</button>
//       </form>
//       {message && <p>{message}</p>}
//     </div>
//   );
// }

// export default ChangePassword;


import React, { useState } from 'react';
import axios from 'axios';
import '../css/changePassword.css'; // Make sure the path is correct

function ChangePassword({ id }) {
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [message, setMessage] = useState('');

  const handleUpdate = async (e) => {
    e.preventDefault();
 
    if (newPassword !== confirmPassword) {
      setMessage('New passwords do not match.');
      return;
    }

    try {
        const res = await axios.put('http://localhost:5000/api/update-password', {
            id:21,
            currentPassword,
            newPassword,
          });

      setMessage(res.data.message);
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err) {
      setMessage(err.response?.data?.message || 'Error updating password');
    }
  };

  return (
    <div className="change-password-container">
      <h2>Change Password</h2>
      <form onSubmit={handleUpdate}>
        <input
          type="password"
          placeholder="Current Password"
          value={currentPassword}
          onChange={(e) => setCurrentPassword(e.target.value)}
          required
        />
        <input
          type="password"
          placeholder="New Password"
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
          required
        />
        <input
          type="password"
          placeholder="Confirm New Password"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          required
        />
        <button type="submit">Update Password</button>
      </form>
      {message && <p className="change-password-message">{message}</p>}
    </div>
  );
}

export default ChangePassword;
