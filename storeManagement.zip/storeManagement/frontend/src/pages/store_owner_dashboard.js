// StoreRatings.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';




function StoreRatings() {

  const navigate = useNavigate();
  const [ratings, setRatings] = useState([]);
  
  useEffect(() => {
    const fetchRatings = async () => {
      try {
        const res = await axios.get(`http://localhost:5000/store/rating`);
        setRatings(res.data);
      } catch (error) {
        console.error('Error fetching ratings:', error);
      }
    };
      
    fetchRatings();
  }, []);

  const handleLogout = () => {
    // Clear user session data
    localStorage.clear();
    // Redirect to login page
    navigate('/login');
  };
  const handleChangePassword = () => {
    navigate('/change-password');
  };

  const styles = {
    nav: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '10px 20px',
      backgroundColor: '#343a40',
      color: 'white',
    },
    title: {
      margin: 0,
      whiteSpace: 'nowrap',
    
    },
    rightGroup: {
      display: 'flex',
      gap: '10px',
    },
    logoutBtn: {
      padding: '8px 12px',
      backgroundColor: 'grey',
      color: 'white',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
      fontWeight: 'bold',
    }
  };

  return (
    <>
 {/* <nav style={styles.nav}>
      <h2 style={styles.title}>Store Management System</h2>
      <button onClick={handleLogout} style={styles.logoutBtn}>
        Logout
      </button>
    </nav> */}
    <nav style={styles.nav}>
  <h2 style={styles.title}>Store Management System</h2>
  <div style={styles.rightGroup}>
    <button onClick={handleLogout} style={styles.logoutBtn}>Logout</button>
    <button onClick={handleChangePassword} style={styles.logoutBtn}>Change Password</button>
  </div>
</nav>

    <div>
      <h2>Ratings for Your Store</h2>
      <table>
        <thead>
          <tr>
            <th>User Name</th>
            <th>Email</th>
            <th>Rating</th>
            {/* <th>Submitted At</th> */}
          </tr>
        </thead>
        <tbody>
          {ratings.map((r, i) => (
            <tr key={i}>
              <td>{r.name}</td>
              <td>{r.email}</td>
              <td>{r.rating}</td>
              {/* <td>{new Date(r.created_at).toLocaleString()}</td> */}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
    </>
  );
}

export default StoreRatings;
