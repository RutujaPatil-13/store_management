import React, { useEffect, useState } from 'react';
import axios from 'axios';
import '../css/storeSearch.css';

function storeSearch() {
  const [stores, setStores] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    fetchStores();
  }, []);

  const fetchStores = async () => {
    try {
      const res = await axios.get('http://localhost:5000/stores');
      setStores(res.data);
    } catch (err) {
      console.error('Error fetching stores:', err);
    }
  };

  const filteredStores = stores.filter(store =>
    store.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    store.address.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="store-container">
      <h2>Browse Stores</h2>
      <input
        type="text"
        className="store-search"
        placeholder="Search by name or address..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />

      <div className="store-list">
        {filteredStores.length === 0 ? (
          <p>No stores found.</p>
        ) : (
          filteredStores.map((store) => (
            <div key={store.id} className="store-card">
              <h3>{store.name}</h3>
              <p>{store.address}</p>
              <p>Rating: {store.avgRating ? store.avgRating.toFixed(1) : 'No ratings yet'}</p>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

export default storeSearch;
