// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import '../css/storeSearch.css'
// export default function StoreList() {
//   const [stores, setStores] = useState([]);
//   const [rating, setRating] = useState(5);

//   useEffect(() => {
//     axios.get('http://localhost:5000/stores').then(res => {
//       setStores(res.data);
//     });
//   }, []);

//   const rateStore = (storeId) => {
//     const token = localStorage.getItem('token');
//     axios.post(`http://localhost:5000/api/stores/${storeId}/rate`, { rating }, {
//       headers: { Authorization: token }
//     }).then(() => alert('Rated!'));
//   };

//   return (
//     <div>
//       <h2>Stores</h2>
//       <ul>
//       {stores.map(store => (
//   <div key={store.id}>
//     <h3>{store.name}</h3>
//     <p>Rating: {store.rating !== undefined ? store.rating.toFixed(1) : 'No rating'}</p>
//   </div>
// ))}
       
//       </ul>
//     </div>
//   );
// }


import React, { useEffect, useState } from 'react';
import axios from 'axios';
import '../css/storeList.css';

export default function StoreList() {
  const [stores, setStores] = useState([]);
  const [rating, setRating] = useState(5);
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    fetchStores();
    const token = localStorage.getItem('token');
    setIsLoggedIn(!!token); // check if token exists
  }, []);

  const fetchStores = async () => {
    try {
      const res = await axios.get('http://localhost:5000/stores');
      setStores(res.data);
    } catch (err) {
      console.error('Error fetching stores:', err);
    }
  };

  const rateStore = (storeId) => {
    const token = localStorage.getItem('token');
    if (!token) {
      alert('Please sign up or log in to rate a store.');
      return;
    }

    axios
      .post(
        `http://localhost:5000/api/stores/${storeId}/rate`,
        { rating },
        { headers: { Authorization: token } }
      )
      .then(() => {
        alert('Rating submitted!');
        fetchStores(); // refresh updated ratings
      })
      .catch((err) => {
        alert('Rating failed.');
        console.error(err);
      });
  };

  const filteredStores = stores.filter((store) =>
    store.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    store.address.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="store-container">
      <h2>Browse Stores</h2>
      <input
        type="text"
        className="store-search"
        placeholder="Search by store name or address..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />

      {filteredStores.length === 0 ? (
        <p>No stores found.</p>
      ) : (
        <table className="store-table">
          <thead>
            <tr>
              <th>Store Name</th>
              <th>Address</th>
              <th>Overall Rating</th>
              {/* <th>Submit Rating</th> */}
            </tr>
          </thead>
          <tbody>
            {filteredStores.map((store) => (
              <tr key={store.id}>
                <td>{store.name}</td>
                <td>{store.address}</td>
                <td>{store.rating !== undefined ? store.rating.toFixed(1) : 'N/A'}</td>
                {/* <td>
                  {isLoggedIn ? (
                    <>
                      <input
                        type="number"
                        min="1"
                        max="5"
                        value={rating}
                        onChange={(e) => setRating(Number(e.target.value))}
                        className="rating-input"
                      />
                      <button
                        className="rate-button"
                        onClick={() => rateStore(store.id)}
                      >
                        Rate
                      </button>
                    </>
                  ) : (
                    <span className="login-warning">Login to rate</span>
                  )}
                </td> */}
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
