const db = require('../config/db');


const addRating = (storeId, userId, rating, callback) => {
  const sql = 'INSERT INTO ratings (id, regi_id, store_id,rating) VALUES (?, ?, ?,?)';
  db.query(sql, [storeId, userId, rating], callback);
};

const getStores = (callback) => {
  // const sql = 'SELECT s.id, s.name, IFNULL(AVG(r.rating), 0) as average_rating FROM stores s LEFT JOIN ratings r ON s.id = r.store_id GROUP BY s.id';
  const sql="select * from store";
  db.query(sql, callback);
};

module.exports = {addRating, getStores };