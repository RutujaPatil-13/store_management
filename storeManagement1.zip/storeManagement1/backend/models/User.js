// const db = require('../config/db');

// const createUser = (user, callback) => {
//   const sql = 'INSERT INTO registration (name,email,password,address) VALUES (?,?,?,?)';
//   db.query(sql, [user.username, user.password, user.role], callback);
// };

// const findUser = (username, callback) => {
//   const sql = 'SELECT * FROM registration WHERE id = ?';
//   db.query(sql, [username], callback);
// };

// module.exports = { createUser, findUser };