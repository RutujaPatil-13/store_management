// In your Express route file (e.g., routes/store.js)
const express = require('express');
const router = express.Router();
const db = require('../config/db');

// GET store details with average rating
router.get('/', (req, res) => {
  const query = `
    SELECT 
      s.id,
      s.name,
      s.store_address,
      s.email
     
    FROM 
      store s
 LEFT JOIN 
      ratings r ON s.id = r.store_id

  `;

  db.query(query, (err, results) => {
    if (err) {
      console.error('Error fetching store data:', err);
      return res.status(500).json({ message: 'Server error' });
    }
    res.json(results);
  });
});

module.exports = router;
