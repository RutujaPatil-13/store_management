// routes/admin.js
const express = require('express');
const db = require('../config/db');
const router = express.Router();

router.get('/api/admin-dashboard-stats', (req, res) => {
  const stats = {};

  const userCountQuery = 'SELECT COUNT(*) AS totalUsers FROM registration WHERE role_id = 3';
  const storeCountQuery = 'SELECT COUNT(*) AS totalStores FROM store';
  const ratingCountQuery = 'SELECT COUNT(*) AS totalRatings FROM ratings';

  db.query(userCountQuery, (err, userResult) => {
    if (err) return res.status(500).json({ message: 'Error fetching users' });

    stats.totalUsers = userResult[0].totalUsers;

    db.query(storeCountQuery, (err, storeResult) => {
      if (err) return res.status(500).json({ message: 'Error fetching stores' });

      stats.totalStores = storeResult[0].totalStores;

      db.query(ratingCountQuery, (err, ratingResult) => {
        if (err) return res.status(500).json({ message: 'Error fetching ratings' });

        stats.totalRatings = ratingResult[0].totalRatings;

        return res.json(stats);
      });
    });
  });
});

module.exports = router;
