const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../config/db'); 

const router = express.Router();

router.put('/api/update-password', async (req, res) => {
    const { id, currentPassword, newPassword } = req.body;

    console.log('Incoming password change request:', { id, currentPassword, newPassword });
  
    if (!id || !currentPassword || !newPassword) {
      console.log('Missing fields in request');
      return res.status(400).json({ message: 'Missing fields' });
    }

    const query = 'SELECT password FROM registration WHERE id = ?';
    db.query(query, [id], async (err, results) => {
      if (err) {
        console.error('DB error on select:', err);
        return res.status(500).json({ message: 'Server error' });
      }
  
      if (results.length === 0) {
        console.log('User not found for id:', id);
        return res.status(404).json({ message: 'User not found' });
      }
  
      const user = results[0];
      const isMatch = await bcrypt.compare(currentPassword, user.password);
      if (!isMatch) {
        console.log('Incorrect current password');
        return res.status(401).json({ message: 'Incorrect current password' });
      }
  
      const hashedPassword = await bcrypt.hash(newPassword, 10);
      const updateQuery = 'UPDATE registration SET password = ? WHERE id IN(21,27,28,29,30,31,32,33,34,35)';
      db.query(updateQuery, [hashedPassword, id], (err) => {
        if (err) {
          console.error('DB error on update:', err);
          return res.status(500).json({ message: 'Error updating password' });
        }
  
        console.log('Password updated successfully for user id:', id);
        return res.json({ message: 'Password updated successfully' });
      });
    });

});

  
module.exports = router;
