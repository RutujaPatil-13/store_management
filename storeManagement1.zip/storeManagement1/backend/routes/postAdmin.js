const express = require('express');
const router = express.Router();
const db = require('../config/db');
const bcrypt = require('bcryptjs');

router.post('/', async (req, res) => {
  const { name, email, password, address } = req.body;

  if (!name || !email || !password || !address) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  try {
    const hashedPassword = await bcrypt.hash(password, 10);

    const query = `
      INSERT INTO registration (name, email, password, address, role_id)
      VALUES (?, ?, ?, ?, ?)
    `;
    const roleId = 1;

    db.query(query, [name, email, hashedPassword, address, roleId], (err, result) => {
      if (err) {
        console.error('DB Error:', err);
        return res.status(500).json({ message: 'Database error' });
      }

      return res.status(201).json({
        message: 'User registered successfully',
        userId: result.insertId
      });
    });

  } catch (err) {
    console.error('Hashing Error:', err);
    return res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
