// const express = require('express');
// const router = express.Router();
// const db = require('../config/db');

// // POST /api/register
// router.post('/', async (req, res) => {
//   const { name, address, email, password } = req.body;

//   if (!name || !address || !email || !password) {
//     return res.status(400).json({ message: 'All fields are required' });
//   }

// // only normal users can register

//   try {
//     const query = 'INSERT INTO registration (name, address, email, password) VALUES ( ?, ?, ?, ?)';
//     const values = [name, address, email, password, role_id];

//     await db.query(query, values);
//     res.status(201).json({ message: 'User registered successfully' });
//   } catch (error) {
//     console.error('Error inserting user:', error);
//     res.status(500).json({ message: 'Failed to register user' });
//   }
// });

// module.exports = router;


const express = require('express');
const router = express.Router();
const db = require('../config/db');
const bcrypt = require('bcryptjs');

router.post('/', async (req, res) => {
  const { name, email, password, address } = req.body;

  // Optional: validate required fields
  if (!name || !email || !password || !address ) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  try {
    const hashedPassword = await bcrypt.hash(password, 10);

    // Insert user into the registration table
    const query = 'INSERT INTO registration (name, email, password, address) VALUES ( ?, ?, ?, ?)';
    db.query(query, [name, email, hashedPassword, address], (err, result) => {
      if (err) {
        console.error('DB Error:', err);
        return res.status(500).json({ message: 'Database error' });
      }

      return res.status(201).json({ message: 'User registered successfully', userId: result.insertId });
    });

  } catch (err) {
    console.error('Hashing Error:', err);
    return res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;



