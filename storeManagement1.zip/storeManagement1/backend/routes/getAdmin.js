const express = require('express');
const router = express.Router();
const db = require('../config/db'); // Adjust to your DB config path

// GET /api/normal-users - Get all users with role_id = 3
router.get('/admin-users', (req, res) => {
//   const query = `
//     SELECT name, email, address, 
//            CASE 
//              WHEN role_id = 3 THEN 'user' 
//              ELSE 'unknown' 
//            END as role
//     FROM registration
//     WHERE role_id = 3
//   `;
// const query =`select name, email, address from registration`


const query =`SELECT 
  r.name, 
  r.email, 
  r.address, 
  rm.role_name AS role
FROM 
  registration r
JOIN 
  role_master rm ON r.role_id = rm.id
WHERE 
  r.role_id = 1;
`



  db.query(query, (err, results) => {
    if (err) {
      console.error('Error fetching users:', err);
      return res.status(500).json({ message: 'Database error' });
    }

    res.status(200).json(results);
  });
});

module.exports = router;
