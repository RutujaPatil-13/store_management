const express = require('express');
const cors = require('cors');
const app = express();
// const authRoutes = require('./routes/auth');
const storeRoutes = require('./routes/store');
const addStoreRoute = require('./routes/addStore');
const addUserRoute = require('./routes/postUser')

const registrationRoutes = require('./routes/registration')
// const mainRoutes = require('./routes/storeOwner')
// const loginRoutes = require('./routes/adminLogin')
const getUserRoute = require('./routes/getUsersCount')

const getUserRoutes = require('./routes/getUser')
const getStoreRoute = require('./routes/getStore')
const postRatingRoute = require('./routes/postRating')
const getAdminRoute = require('./routes/getAdmin')
const login = require('./routes/login ')
const AdminRoute = require('./routes/postAdmin')
const storeOwnerRoutes = require('./routes/storeOwner')
const ChangePasswordRoute = require('./routes/changePassword')

app.use(cors());

app.use(express.json());

// app.use('api/users', authRoutes);



// Mount registration route at /api/register
app.use('/api/register', registrationRoutes);

app.use('/stores', storeRoutes);
// app.use('/store-owner', mainRoutes);
// app.use('/login',loginRoutes);
app.use('/', getUserRoute);
app.use('/api/stores', addStoreRoute);
app.use('/api/user', addUserRoute);

app.use('/api/getstore', getStoreRoute);
app.use('/', postRatingRoute);

app.use('/api', getUserRoutes);
app.use('/', getAdminRoute);
app.use('/', storeOwnerRoutes);
app.use('/api', login);
app.use('/api/Admin', AdminRoute);
app.use('/', ChangePasswordRoute);


const PORT = 5000;

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});