// const mysql = require('mysql2');
// const connection = mysql.createConnection({
//   host: 'localhost',
//   user: 'root',
//   password: '',
//   database: 'store_management',

// });
// connection.connect((err) => {
//   if (err) throw err;
//   console.log('MySQL Connected...');
// });
// module.exports = connection;

const mysql = require('mysql2');
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'store_management',
});

db.connect((err) => {
  if (err) {
    console.error('DB connection error:', err);
    return;
  }
  console.log('Database connected');
});

module.exports = db;
