import React, { useEffect, useState } from 'react';
import axios from 'axios';
import '../css/dashboard.css'; // optional for better styles
import { useNavigate } from 'react-router-dom';
import StarRatingDisplay from './ratingDisplay';
// import changPass from '../pages/changePassword'


function UserDashboard({id}) {
  const [stores, setStores] = useState([]);
  const [search, setSearch] = useState('');
  const [rating, setRating] = useState({});
  const [searchTerm, setSearchTerm] = useState('');
  const userId = id; 
  const navigate = useNavigate();
  // Fetch all stores on component mount
  useEffect(() => {
    fetchStores();
  }, []);

  const fetchStores = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/getstore');
      setStores(res.data);
    } catch (err) {
      console.error('Failed to fetch stores:', err);
    }
  };
  const handleChangePassword = () => {
    navigate('/change-password');
  };

  const handleRatingSubmit = async (storeId) => {
    const value = parseInt(rating[storeId]);
    if (!value || value < 1 || value > 5) {
      alert('Rating must be between 1 and 5');
      return;
    }
    // const handleSubmit = () => {
    //   alert(`You rated: ${selectedRating} stars`);
    //   // You can now POST this rating to your backend
    // };
  

  
    try {
      await axios.post(`http://localhost:5000/api/postrating/${storeId}/rating`, { rating: value  });
      alert('Rating submitted!');
      fetchStores(); // refresh store list with updated rating
    } catch (err) {
      alert('Rating submission failed');
      console.error(err);
    }
  };

  const filteredStores = stores.filter(store =>
    store.name?.toLowerCase().includes((searchTerm || '').toLowerCase())||
    store.store_address?.toLowerCase().includes((searchTerm || '').toLowerCase())
    
  );
  const handleLogout = () => {

    localStorage.clear();
   
    navigate('/login');
  };
  const styles = {
    nav: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '10px 20px',
      backgroundColor: '#343a40',
      color: 'white',
    },
    title: {
      margin: 0,
      whiteSpace: 'nowrap',
    },
    rightGroup: {
      display: 'flex',
      gap: '10px',
    },
    logoutBtn: {
      padding: '8px 12px',
      backgroundColor: 'grey',
      color: 'white',
      border: 'none',
      borderRadius: '4px',
      cursor: 'pointer',
      fontWeight: 'bold',
    },
  };
  
  
  return (
    <>
   
<nav style={styles.nav}>
  <h2 style={styles.title}>Store Management System</h2>
  <div style={styles.rightGroup}>
    <button onClick={handleLogout} style={styles.logoutBtn}>Logout</button>
    <button onClick={handleChangePassword} style={styles.logoutBtn}>Change Password</button>
  </div>
</nav>


    <div className="user-dashboard">
      <h2>Store Searching</h2>
      <input
        className="search-box"
        type="text"
        placeholder="Search by store name or address"
        value={searchTerm}
  onChange={(e) => setSearchTerm(e.target.value)}
      />

      <table className="store-table">
        <thead>
          <tr>
            <th>Store Name</th>
            <th>Address</th>
            <th>Overall Rating</th>
            <th>Rate (1–5)</th>
            <th>Submit</th>
            <th>Update Submit</th>
          </tr>
        </thead>
        <tbody>
          {filteredStores.map((store) => (
            <tr key={store.id}>
              <td>{store.name}</td>
              <td>{store.store_address}</td>
          
             {/* <td>{store.rating}</td> */}
             <td>{store.rating ? store.rating.toFixed(1) : 'No ratings yet'}</td>
              <td>
                <td><StarRatingDisplay
  rating={rating[store.id] || 0}
  onRatingChange={(value) => setRating({ ...rating, [store.id]: value })}
/>
</td>
                {/* <input
                  type="number"
                  min="1"
                  max="5"
                  value={rating[store.id] || ''}
                  onChange={(e) => setRating({ ...rating, [store.id]: e.target.value })}
                  className="rating-input"
                /> */}
              </td>
              <td>
                <button onClick={() => handleRatingSubmit(store.id)} className="rate-btn">
                  Submit
                </button>
              </td>
              <td>
                <button onClick={() => handleRatingSubmit(store.id)} className="rate-btn">
                  Update
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
    </>
  );
}

export default UserDashboard;
