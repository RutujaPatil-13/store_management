// import React, { useState, useEffect } from 'react';
// import axios from 'axios';

// function AdminDashboard() {
//   const [view, setView] = useState(''); // 'users' or 'stores'
//   const [users, setUsers] = useState([]);
//   const [stores, setStores] = useState([]);

//   useEffect(() => {
//     if (view === 'users') {
//       fetchUsers();
//     } else if (view === 'stores') {
//       fetchStores();
//     }
//   }, [view]);

//   const fetchUsers = async () => {
//     try {
//       const res = await axios.get('http://localhost:5000/users');
//       setUsers(res.data);
//     } catch (err) {
//       console.error('Error fetching users:', err);
//     }
//   };

//   const fetchStores = async () => {
//     try {
//       const res = await axios.get('http://localhost:5000/stores');
//       setStores(res.data);
//     } catch (err) {
//       console.error('Error fetching stores:', err);
//     }
//   };

//   return (
//     <div style={{ padding: '2rem', fontFamily: 'Arial, sans-serif' }}>
//       <h2>Admin Dashboard</h2>
//       <div style={{ marginBottom: '1rem' }}>
//         <button
//           style={{ marginRight: '1rem', padding: '0.5rem 1rem' }}
//           onClick={() => setView('users')}
//         >
//           Users
//         </button>
//         <button
//           style={{ padding: '0.5rem 1rem' }}
//           onClick={() => setView('stores')}
//         >
//           Stores
//         </button>
//       </div>

//       {view === 'users' && (
//         <div>
//           <h3>User Information</h3>
//           {users.length === 0 ? (
//             <p>No users found.</p>
//           ) : (
//             <table
//               style={{ borderCollapse: 'collapse', width: '100%' }}
//               border="1"
//             >
//               <thead>
//                 <tr>
//                   <th>Name</th>
//                   <th>Email</th>
//                   <th>Address</th>
//                 </tr>
//               </thead>
//               <tbody>
//                 {users.map((user) => (
//                   <tr key={user.id}>
//                     <td>{user.name}</td>
//                     <td>{user.email}</td>
//                     <td>{user.address}</td>
//                   </tr>
//                 ))}
//               </tbody>
//             </table>
//           )}
//         </div>
//       )}

//       {view === 'stores' && (
//         <div>
//           <h3>Store Information</h3>
//           {stores.length === 0 ? (
//             <p>No stores found.</p>
//           ) : (
//             <table
//               style={{ borderCollapse: 'collapse', width: '100%' }}
//               border="1"
//             >
//               <thead>
//                 <tr>
//                   <th>Store Name</th>
//                   <th>Address</th>
//                 </tr>
//               </thead>
//               <tbody>
//                 {stores.map((store) => (
//                   <tr key={store.id}>
//                     <td>{store.name}</td>
//                     <td>{store.address}</td>
//                   </tr>
//                 ))}
//               </tbody>
//             </table>
//           )}
//         </div>
//       )}
//     </div>
//   );
// }

// export default AdminDashboard;

// 
// import React, { useEffect, useState } from 'react';
// import axios from 'axios';
// import '../css/adminDashboard';

// function AdminDashboard() {
//   const [totalUsers, setTotalUsers] = useState(0);
//   const [view, setView] = useState('overview');

//   useEffect(() => {
//     fetchTotalUsers();
//   }, []);

//   const fetchTotalUsers = async () => {
//     try {
//       const res = await axios.get('http://localhost:5000/api/users/count');
//       setTotalUsers(res.data.count);
//     } catch (err) {
//       console.error('Failed to fetch user count:', err);
//     }
//   };

//   return (
//     <div className="admin-dashboard">
//       <aside className="sidebar">
//         <h2>Admin</h2>
//         <ul>
//           <li onClick={() => setView('overview')}>Dashboard</li>
//           <li onClick={() => setView('newStores')}>New Stores</li>
//           <li onClick={() => setView('normalUsers')}>Normal Users</li>
//           <li onClick={() => setView('adminUsers')}>Admin Users</li>
//         </ul>
//       </aside>

//       <main className="dashboard-content">
//         <h1>Admin Dashboard</h1>
//         {view === 'overview' && (
//           <div className="card">
//             <h3>Total Users</h3>
//             <p>{totalUsers}</p>
//           </div>
//         )}
//         {view === 'newStores' && <p>Display new stores here...</p>}
//         {view === 'normalUsers' && <p>Display normal users here...</p>}
//         {view === 'adminUsers' && <p>Display admin users here...</p>}
//       </main>
//     </div>
//   );
// }

// export default AdminDashboard;


import React, { useState, useEffect , } from 'react';
import axios from 'axios';
import '../css/adminDashboard.css'; // Link to the CSS file
import { useNavigate } from 'react-router-dom';




function AdminDashboard() {
    const [view, setView] = useState('home');
  const [stores, setStores] = useState([]);
  const [normalUsers, setNormalUsers] = useState([]);
  const [adminUsers, setAdminUsers] = useState([]);
  const [userCountt, setUserCount] = useState(0);
  const [searchTerm, setSearchTerm] = useState('');
    const [register, setregister] = useState([]);
  const navigate = useNavigate();
  
  useEffect(() => {
    if (view === 'home') fetchTotalUsers();
    if (view === 'newStores') fetchStores();
    if (view === 'storeOwner') fetchStoreOwner();
    if (view === 'normalUsers') fetchNormalUsers();
    if (view === 'adminUsers') fetchAdminUsers();
    if (view === 'userRole')  fetchNormalUsers();
    if (view === 'logout')  fetchNormalUsers();
      
  }, [view]);

  const [stats, setStats] = useState({
    totalUsers: 1,
    totalStores: 2,
    totalRatings: 2,
  });

  const fetchStores = async () => {
    try {
      const res = await axios.get('http://localhost:5000/stores');
      setStores(res.data);
    } catch (err) {
      console.error('Error fetching stores:', err);
    }
  };

  const fetchNormalUsers = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/normal-users');
      setNormalUsers(res.data);
    } catch (err) {
      console.error('Error fetching normal users:', err);
    }
  };

  const fetchAdminUsers = async () => {
    try {
      const res = await axios.get('http://localhost:5000/admin-users');
      setAdminUsers(res.data);
    } catch (err) {
      console.error('Error fetching admin users:', err);
    }
  };
  const fetchTotalUsers = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/admin-dashboard-stats');
      setUserCount(res.data.count);
    } catch (err) {
      console.error('Error fetching total users:', err);
    }
  };
// useEffect(() => {
//     axios.get('http://localhost:5000/api/userCount')
//       .then(res => {
//         setTotalUsers(res.data.total); 
//       })
//       .catch(err => {
//         console.error('Error fetching total users:', err);
//       });
//   }, []);
const handleLogout = () => {
    
    navigate('/login');
  };

  const user = register.filter((registration) =>
    registration.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    registration.role.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="admin-dashboard">
      <div className="sidebar">
        <h3>Admin Dashboard</h3>

        <button onClick={() => setView('home')}> Home</button>
        <button onClick={() => setView('newStores')}>New Stores</button>
        {/* <button onClick={() => setView('newStores')}>New Store Owner</button> */}
        <button onClick={() => setView('normalUsers')}>Normal Users</button>
        <button onClick={() => setView('adminUsers')}>Admin Users</button>
    
        <button onClick={handleLogout}>Logout</button>
      </div>

      <div className="main-content">
      {view === 'home' && (
  <div className="dashboard-summary">
    <h2>Welcome to Admin Home</h2>

    <div className="cards-container">
    <div className="card">
            <h3>Total Users</h3>
            <p>{stats.totalUsers}</p>
          </div>
          <div className="card">
            <h3>Total Stores</h3>
            <p>{stats.totalStores}</p>
          </div>
          <div className="card">
            <h3>Total Ratings</h3>
            <p>{stats.totalRatings}</p>
          </div>
  </div>
  </div>
)}
      {view === 'newStores' && (
  <>
    <div className="header-with-button">
      <h2>New Store List</h2>
      <button className="add-store-btn" onClick={() => navigate('/add-store')}>
        + Add New Store
      </button>
    </div>
    <table>
      <thead>
        <tr><th>Name</th><th>Address</th><th>Email</th><th>Rating</th></tr>
      </thead>
      <tbody>
        {stores.map(store => (
          <tr key={store.id}>
            <td>{store.name}</td>
            <td>{store.store_address}</td>
            <td>{store.email}</td>
            <td>{store.rating || 'N/A'}</td>
          </tr>
        ))}
      </tbody>
    </table>
  </>
)}


        {view === 'normalUsers' && (
          <>
            <h2>List Normal Users</h2>
            <div className="header-with-button">
            <input
        type="text"
        className="store-search"
        placeholder="Search by name "
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />

      <button className="add-store-btn" onClick={() => navigate('/add-user')}>
        + Add New User
      </button>
    </div>
            <table>
              <thead>
                <tr><th>Name</th><th>Email</th><th>Address</th><th>Role</th></tr>
              </thead>
              <tbody>

              {normalUsers
          .filter(user =>
            user.name.toLowerCase().includes(searchTerm.toLowerCase())
          )
                .map(user => (
                  <tr key={user.id}>
                    <td>{user.name}</td>
                    <td>{user.email}</td>
                    <td>{user.address}</td>
                    <td>{user.role}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </>
        )}

        {view === 'adminUsers' && (
          <>
           <h2>List Admin Users</h2>
            <div className="header-with-button">
            <input
        type="text"
        className="store-search"
        placeholder="Search by name "
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />

      <h2>Admin List</h2>
      <button className="add-store-btn" onClick={() => navigate('/add-admin')}>
        + Add New User
      </button>
    </div>
            <table>
              <thead>
                <tr><th>Name</th><th>Email</th><td>Address</td><td>Role</td></tr>
              </thead>
              <tbody>
              {adminUsers
          .filter(user =>
            user.name.toLowerCase().includes(searchTerm.toLowerCase())
          )
              .map(admin => (
                  <tr key={admin.id}>
                    <td>{admin.name}</td>
                    <td>{admin.email}</td>
                    <td>{admin.address}</td>
                    <td>{admin.role}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </>
        )}
       
     
      </div>
    </div>
  );
}

export default AdminDashboard;
