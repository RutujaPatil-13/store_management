// import React, { useState } from 'react';
// import axios from 'axios';
// import '../css/register.css';
// import { useNavigate } from 'react-router-dom';


// function Register() {
//   const [data, setData] = useState({
//     name: "",
//     address: "",
//     password: "",
//     email: "",

//   });

//   const [errors, setErrors] = useState({});
//   const navigate = useNavigate();


//   const validate = () => {
//     const errs = {};

//     if (!data.name.trim()) {
//       errs.name = "Name is required";
//     } else if (data.name.length < 20 || data.name.length > 60) {
//       errs.name = "Name must be between 20 and 60 characters";
//     }
//     if (!data.address) {
//       errs.address = "Address is required";
//     } else if (data.address.length > 400) {
//       errs.address = "Address cannot exceed 400 characters";
//     }

//     if (!data.password) {
//       errs.password = "Password is required";
//     } else if (
//       data.password.length < 8 ||
//       data.password.length > 16 ||
//       !/[A-Z]/.test(data.password) ||
//       !/[!@#$%^&*(),.?":{}|<>]/.test(data.password)
//     ) {
//       errs.password =
//         "Password must be 8-16 characters and include at least one uppercase letter and one special character";
//     }

//     if (!data.email) {
//       errs.email = "Email is required";
//     } else {
//       const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
//       if (!emailRegex.test(data.email)) {
//         errs.email = "Invalid email address";
//       }
//     }


//     return errs;
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     const validationErrors = validate();
//     setErrors(validationErrors);

//     if (Object.keys(validationErrors).length === 0) {
//       try {
//         await axios.post('http://localhost:5000/api/register', data);
//         alert('Registered!');
//         navigate('/login'); 
//       } catch (error) {
//         alert('Registration failed.');
//         console.error(error);
//       }
//     }
//   };

//   return (
//     <form className="register-form" onSubmit={handleSubmit} noValidate>
//       <input
//         className="input-field"
//         type="text"
//         placeholder="Name"
//         value={data.name}
//         onChange={(e) => setData({ ...data, name: e.target.value })}
//       />
//       {errors.name && <p className="error-text">{errors.name}</p>}

//       <textarea
//         className="input-field"
//         placeholder="Address"
//         value={data.address}
//         onChange={(e) => setData({ ...data, address: e.target.value })}
//         rows={4}
//       />
//       {errors.address && <p className="error-text">{errors.address}</p>}

//       <input
//         className="input-field"
//         type="password"
//         placeholder="Password"
//         value={data.password}
//         onChange={(e) => setData({ ...data, password: e.target.value })}
//       />
//       {errors.password && <p className="error-text">{errors.password}</p>}

//       <input
//         className="input-field"
//         type="email"
//         placeholder="Email"
//         value={data.email}
//         onChange={(e) => setData({ ...data, email: e.target.value })}
//       />
//       {errors.email && <p className="error-text">{errors.email}</p>}

//       {/* <select
//         className="input-field"
//         value={data.role}
//         onChange={(e) => setData({ ...data, role: e.target.value })}
//       >
//         <option value="admin">Admin</option>
//         <option value="store_owner">Store Owner</option>
//         <option value="user">User</option>
//       </select>
//       {errors.role && <p className="error-text">{errors.role}</p>} */}

//       <button className="submit-btn" type="submit">
//         Register
//       </button>
//     </form>
//   );
// }

// export default Register;


import React, { useState } from 'react';
import axios from 'axios';
import'../css/register.css'
import { useNavigate } from 'react-router-dom';

function Register() {
  const [data, setData] = useState({
    name: "",
    address: "",
    password: "",
    email: "",
  });

  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  const validate = () => {
    const errs = {};

    if (!data.name.trim()) {
      errs.name = "Name is required";
    } else if (data.name.length < 20 || data.name.length > 60) {
      errs.name = "Name must be between 20 and 60 characters";
    }

    if (!data.address) {
      errs.address = "Address is required";
    } else if (data.address.length > 400) {
      errs.address = "Address cannot exceed 400 characters";
    }

    if (!data.password) {
      errs.password = "Password is required";
    } else if (
      data.password.length < 8 ||
      data.password.length > 16 ||
      !/[A-Z]/.test(data.password) ||
      !/[!@#$%^&*(),.?":{}|<>]/.test(data.password)
    ) {
      errs.password =
        "Password must be 8-16 characters and include at least one uppercase letter and one special character";
    }

    if (!data.email) {
      errs.email = "Email is required";
    } else {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
      if (!emailRegex.test(data.email)) {
        errs.email = "Invalid email address";
      }
    }

    return errs;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const validationErrors = validate();
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length === 0) {
      try {
        await axios.post('http://localhost:5000/api/register', {
          
          role: 'user'
           ,...data
        });
        alert('Registered!');
        navigate('/login');
      } catch (error) {
        alert('Registration failed.');
        console.error(error);
      }
    }
  };


  return (
    <form className="register-form" onSubmit={handleSubmit} noValidate>
      <h3>Registration Form</h3>
      <input
        className="input"
        type="text"
        placeholder="Name"
        value={data.name}
        onChange={(e) => setData({ ...data, name: e.target.value })}
      />
      {errors.name && <p className="error-text">{errors.name}</p>}

      <textarea
        className="input"
        placeholder="Address"
        value={data.address}
        onChange={(e) => setData({ ...data, address: e.target.value })}
        rows={4}
      />
      {errors.address && <p className="error-text">{errors.address}</p>}

      <input
        className="input"
        type="password"
        placeholder="Password"
        value={data.password}
        onChange={(e) => setData({ ...data, password: e.target.value })}
      />
      {errors.password && <p className="error-text">{errors.password}</p>}

      <input
        className="input"
        type="email"
        placeholder="Email"
        value={data.email}
        onChange={(e) => setData({ ...data, email: e.target.value })}
      />
      {errors.email && <p className="error-text">{errors.email}</p>}

      <button className="submit-btn" type="submit">
        Register
      </button>
    </form>
  );
}

export default Register;
