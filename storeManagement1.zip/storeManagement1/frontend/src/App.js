import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Register from './pages/Register';
import Login from './pages/Login';
import StoreList from './pages/StoreList';

import AdminDashboard from './pages/admin_dashboard';
import UserDashboard from './pages/user';
import Header from './components/header';
import '../src/css/header.css';
import Home from './pages/home';
import Home1 from './pages/home1';
import AddStore from './pages/addStore';
import StoreOwnerDashboard from './pages/store_owner_dashboard';
import AddUserForm from './pages/addUser';
import AddAdminForm from './pages/addAdmin';
import ChangePassword from './pages/changePassword';

function App() {
  return (
    <BrowserRouter>
      <Routes>
      {/* <Route path="/" element={<Header />} /> */}
      <Route path="/home" element={<Home1 />} />
      <Route path="/" element={<Home />} />
      <Route path="/storeSearch" element={<StoreList />} />
        <Route path="/register" element={<Register />} />
        <Route path="/login" element={<Login />} />
        <Route path="/storeOwner" element={< StoreOwnerDashboard/>} />
        <Route path="/adminDashboard" element={< AdminDashboard/>} />
        <Route path="/userDashboard" element={< UserDashboard/>} />
        <Route path="/add-store" element={< AddStore/>} />
        <Route path="/add-user" element={< AddUserForm/>} />
        <Route path="/add-admin" element={< AddAdminForm/>} />
        <Route path="/change-password" element={< ChangePassword/>} />

      </Routes>
    </BrowserRouter>
  );
}

export default App;