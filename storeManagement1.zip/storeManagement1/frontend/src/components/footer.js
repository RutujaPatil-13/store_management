import React from 'react';
import '../css/header.css';

function Footer() {
  return (
    <footer className="footer">
      
    </footer>
  );
}

export default Footer;
